package jhajhria.com.brewery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BreweryApplicationTests {

	@Test
	void contextLoads() {
	}

}
